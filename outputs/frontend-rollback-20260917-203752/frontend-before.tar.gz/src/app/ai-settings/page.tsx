"use client";
import { useState } from "react";
import { AudioLines, Check, ChevronRight, Cpu, Globe2, Image as ImageIcon, Layers3, MessageSquare, PenLine, RotateCcw, Save, Search, Settings2, Sparkles, WandSparkles } from "lucide-react";
import { AI_EFFORTS, AI_GROUPS, AI_POLICIES, type AiEffort } from "@/lib/ai-policy-catalog";
import { useAiSettings } from "./useAiSettings";
import "./settings.css";

const icons = [Layers3, Sparkles, PenLine, MessageSquare, WandSparkles, ImageIcon];
const effortLabels = { default: "沿用默认", none: "不指定 · none", low: "轻量 · low", medium: "均衡 · medium", high: "深入 · high", xhigh: "最高 · xhigh" };
export default function AiSettingsPage() {
  const w = useAiSettings();
  const [group, setGroup] = useState<string>(AI_GROUPS[0]);
  const [search, setSearch] = useState("");
  const [bulkModel, setBulkModel] = useState("");
  const [bulkEffort, setBulkEffort] = useState("");
  const visible = AI_POLICIES.filter((p) => (group === "全部链路" || group === p.group) && `${p.title}${p.description}${p.id}`.toLowerCase().includes(search.toLowerCase()));
  const textIds = visible.filter((p) => !("kind" in p)).map((p) => p.id);
  return <div className="ai-settings-page" data-unsaved-changes={w.dirty ? "true" : undefined}>
    <header className="page-header ai-settings-header">
      <div><h1>AI 模型配置</h1><p>把合适的模型，分配给每一步创作。</p></div>
      <div className="ai-header-actions"><span className={`ai-save-state ${w.dirty ? "pending" : ""}`}><span />{w.loading ? "读取中" : w.error ? "需要处理" : w.dirty ? `${w.dirtyIds.length} 项待保存` : "配置已同步"}</span><button className="btn primary" disabled={!w.dirty || w.saving || w.loading} onClick={() => void w.save()}><Save size={15}/>{w.saving ? "保存中…" : "保存更改"}</button></div>
    </header>
    <div className="ai-settings-shell" aria-busy={w.loading || w.saving}>
      <aside className="ai-category-pane">
        <div className="ai-category-title"><Settings2 size={15}/><span>按业务配置</span></div>
        <nav aria-label="AI 业务分类">{AI_GROUPS.map((name, i) => { const Icon = icons[i]; const count = name === "全部链路" ? AI_POLICIES.length : AI_POLICIES.filter((p) => p.group === name).length; return <button key={name} type="button" aria-pressed={group === name} className={group === name ? "selected" : ""} onClick={() => setGroup(name)}><Icon size={17}/><span>{name}</span><small>{count}</small></button>; })}</nav>
        <div className="ai-sidebar-note"><Cpu size={22}/><strong>配置一次，统一生效</strong><p>每个环节独立选择模型与推理等级。保存后用于新请求，无需重启。</p><p>已发出的请求继续完成，已有作品保持原样。</p></div>
        <a className="ai-reference-link" href="https://ui.shadcn.com" target="_blank" rel="noreferrer">界面参考 shadcn/ui <ChevronRight size={13}/></a>
      </aside>
      <section className="ai-settings-content" aria-label="模型配置列表">
        {w.error ? <div className="ai-message error" role="alert"><span>{w.error}</span><button className="btn small" disabled={w.saving} onClick={() => { if (!w.dirty || window.confirm("重新载入将丢弃当前未保存修改，确定继续吗？")) void w.load(); }}>重新载入</button></div> : null}
        {w.message ? <div className="ai-message success" role="status"><Check size={16}/>{w.message}</div> : null}
        {w.loading ? <div className="ai-loading" role="status"><Cpu size={28}/><p>正在读取模型配置…</p></div> : w.saved ? <>
          <section className="ai-overview" aria-label="默认服务概览">
            <div><span><Cpu size={15}/>对话默认</span><strong>{w.saved.services.chat}</strong><small>单独配置可覆盖默认模型</small></div>
            <div><span><Globe2 size={15}/>联网检索</span><strong>{w.saved.services.web}</strong><small>独立 Responses 服务</small></div>
            <div><span><ImageIcon size={15} aria-hidden="true"/>图片默认</span><strong>{w.saved.services.image}</strong><small>图片质量在生图工作台设置</small></div>
          </section>
          <div className="ai-section-heading"><div><h2>{group === "全部链路" ? "创作链路" : group}<span>{visible.length}</span></h2><p>留空模型名沿用节点默认；支持输入后端提供的其他模型 ID。</p></div><label className="ai-search"><Search size={16}/><span className="sr-only">搜索链路</span><input value={search} onChange={(e) => setSearch(e.target.value)} placeholder="搜索业务环节…" /></label></div>
          <fieldset className="ai-bulk-bar" disabled={w.saving}><legend className="sr-only">批量调整当前列表的对话模型</legend><span>批量设置</span><label><span className="sr-only">批量模型</span><input list="ai-text-models" value={bulkModel} placeholder="选择或输入模型" onChange={(e) => setBulkModel(e.target.value)}/></label><label><span className="sr-only">批量推理等级</span><select value={bulkEffort} onChange={(e) => setBulkEffort(e.target.value)}><option value="">推理等级不变</option>{["default", ...AI_EFFORTS].map((effort) => <option key={effort} value={effort}>{effortLabels[effort as keyof typeof effortLabels]}</option>)}</select></label><button type="button" className="btn small" disabled={(!bulkModel && !bulkEffort) || !textIds.length} onClick={() => w.change(textIds, { ...(bulkModel ? { model: bulkModel } : {}), ...(bulkEffort ? { effort: bulkEffort as AiEffort | "default" } : {}) })}>应用到 {textIds.length} 个对话环节</button></fieldset>
          <div className="ai-policy-list" role="region" aria-label="链路配置" tabIndex={0}>{visible.length ? visible.map((p) => { const value = w.overrides[p.id] || w.saved!.defaults[p.id]; const image = "kind" in p; return <fieldset disabled={w.saving} className={`ai-policy-row ${w.dirtyIds.includes(p.id) ? "changed" : ""}`} key={p.id}>
            <legend className="sr-only">{p.title}</legend>
            <div className="ai-policy-info"><span className="ai-policy-group">{p.group}{w.overrides[p.id] ? <span className="ai-override-badge">自定义</span> : null}</span><h3>{p.title}</h3><p>{p.description}</p></div>
            <label className="ai-policy-field"><span>模型</span><input list={image ? "ai-image-models" : "ai-text-models"} value={value.model} placeholder={`默认 · ${w.saved!.inheritedModels[p.id]}`} onChange={(e) => w.change([p.id], { model: e.target.value })}/></label>
            <label className="ai-policy-field"><span>{image ? "推理等级" : "推理强度"}</span>{image ? <div className="ai-not-applicable">图片模型不适用</div> : <select value={value.effort} onChange={(e) => w.change([p.id], { effort: e.target.value as AiEffort | "default" })}>{["default", ...AI_EFFORTS].map((effort) => <option value={effort} key={effort}>{effortLabels[effort as keyof typeof effortLabels]}</option>)}</select>}</label>
            <button type="button" className="btn icon small ai-reset-row" aria-label={`恢复${p.title}默认配置`} title="恢复默认配置" disabled={!w.overrides[p.id] || w.saving} onClick={() => w.change([p.id], null)}><RotateCcw size={14}/></button>
          </fieldset>; }) : <div className="ai-empty"><Search size={24}/><h3>没有匹配的链路</h3><p>试试“评论”“风格”或“图片”。</p></div>}
          <div className="ai-service-note"><AudioLines size={18}/><div><strong>语音转写 · 火山 ASR</strong><p>{w.saved.services.asr} · 语音识别没有推理等级。转写稿模型清洗目前{w.saved.services.transcriptCleaning ? "已开启" : "默认关闭"}。</p></div></div></div>
          <footer className="ai-settings-footer"><p aria-live="polite">{w.dirty ? `${w.dirtyIds.length} 个环节已修改，保存后生效。` : "当前设置已保存。恢复默认也需要点击保存。"}</p><div><button className="btn" disabled={w.saving || !visible.length} onClick={() => w.change(visible.map((p) => p.id), null)}><RotateCcw size={14}/>恢复当前列表默认</button><button className="btn" disabled={!w.dirty || w.saving} onClick={w.discard}>撤销修改</button></div></footer>
          <datalist id="ai-text-models">{w.saved.models.filter((m) => !m.startsWith("gpt-image")).map((m) => <option key={m} value={m}/>)}</datalist><datalist id="ai-image-models">{w.saved.models.filter((m) => m.startsWith("gpt-image")).map((m) => <option key={m} value={m}/>)}</datalist>
        </> : null}
      </section>
    </div>
  </div>;
}
