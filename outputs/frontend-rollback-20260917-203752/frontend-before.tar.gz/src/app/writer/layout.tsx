import "./writer.css";
import "./writer-studio.css";

export default function WriterLayout({ children }: { children: React.ReactNode }) {
  return children;
}
