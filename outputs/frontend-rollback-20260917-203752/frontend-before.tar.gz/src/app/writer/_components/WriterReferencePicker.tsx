"use client";

import { useMemo, useRef, useState } from "react";
import * as Popover from "@radix-ui/react-popover";
import { Command } from "cmdk";
import { Check, ChevronsUpDown, Folder, Search, UserRound, X } from "lucide-react";
import { formatPlatform } from "@/components/Formatters";
import { writeStyleReferenceKey } from "@/lib/write-references";
import type { AccountListItem, ProjectListItem, WriteStyleReferenceInput } from "@/lib/types";

type WriterReferencePickerProps = {
  accounts: AccountListItem[];
  disabled?: boolean;
  onChange: (references: WriteStyleReferenceInput[]) => void;
  projects: ProjectListItem[];
  references: WriteStyleReferenceInput[];
};

const MAX_CONCURRENT_STYLES = 8;

export function WriterReferencePicker({ accounts, disabled, onChange, projects, references }: WriterReferencePickerProps) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<"account" | "project">("account");
  const [multi, setMulti] = useState(false);
  const searchRef = useRef<HTMLInputElement>(null);
  const multiple = multi || references.length > 1;
  const options = useMemo(() => [
    ...accounts.map((account) => ({
      key: writeStyleReferenceKey({ targetType: "account", platform: account.platform, accountId: account.id }),
      label: account.name,
      meta: formatPlatform(account.platform),
      reference: { targetType: "account" as const, platform: account.platform, accountId: account.id }
    })),
    ...projects.map((project) => ({
      key: writeStyleReferenceKey({ targetType: "project", projectId: project.id }),
      label: project.name,
      meta: `${project.sourceAccounts.length} 个参考账号`,
      reference: { targetType: "project" as const, projectId: project.id }
    }))
  ], [accounts, projects]);
  const selectedKeys = new Set(references.map(writeStyleReferenceKey));
  const selected = options.filter((option) => selectedKeys.has(option.key));
  const visible = options.filter((option) => option.reference.targetType === category
    && `${option.label} ${option.meta}`.toLowerCase().includes(query.trim().toLowerCase()));

  return (
    <div className="writer-style-select">
      <Popover.Root open={open && !disabled} onOpenChange={(next) => {
        setOpen(next);
        if (next) {
          setQuery("");
          setCategory(references[0]?.targetType === "project" ? "project" : "account");
        }
      }}>
        <Popover.Trigger asChild>
          <button className="btn writer-style-select-trigger" disabled={disabled} type="button" aria-label="选择风格卡">
            {references[0]?.targetType === "project" ? <Folder size={16} aria-hidden="true" /> : <UserRound size={16} aria-hidden="true" />}
            <span>{disabled ? "载入风格…" : selected.length > 1 ? `${selected.length} 张风格卡` : selected[0]?.label || "选择风格卡"}</span>
            {selected.length === 1 ? <small>{selected[0].meta}</small> : null}
            <ChevronsUpDown size={14} aria-hidden="true" />
          </button>
        </Popover.Trigger>
        <Popover.Portal>
          <Popover.Content className="writer-style-popover" align="start" sideOffset={8} collisionPadding={16} aria-label="选择写作风格" onOpenAutoFocus={(event) => { event.preventDefault(); searchRef.current?.focus(); }}>
            <div className="writer-style-popover-head">
              <div className="segmented" role="group" aria-label="风格来源">
                {(["account", "project"] as const).map((kind) => (
                  <button className={category === kind ? "active" : ""} aria-pressed={category === kind} key={kind} type="button" onClick={() => { setCategory(kind); setQuery(""); }}>
                    {kind === "account" ? <UserRound size={14} aria-hidden="true" /> : <Folder size={14} aria-hidden="true" />}
                    {kind === "account" ? "账号" : "项目"}
                  </button>
                ))}
              </div>
              <label className="writer-style-multiple"><input type="checkbox" checked={multiple} onChange={(event) => {
                setMulti(event.target.checked);
                if (!event.target.checked && references.length > 1) onChange(references.slice(0, 1));
              }} />多选</label>
            </div>
            <Command shouldFilter={false} loop label="搜索风格卡">
              <div className="writer-style-search">
                <Search size={16} aria-hidden="true" />
                <Command.Input ref={searchRef} aria-label="搜索风格卡" placeholder={category === "account" ? "搜索账号或平台…" : "搜索项目…"} value={query} onValueChange={setQuery} />
              </div>
              <Command.List className="writer-style-list">
                <Command.Empty className="writer-style-no-results">没有匹配的{category === "account" ? "账号" : "项目"}</Command.Empty>
                {visible.map((option) => {
                  const checked = selectedKeys.has(option.key);
                  return (
                    <Command.Item key={option.key} value={option.key} disabled={multiple && !checked && references.length >= MAX_CONCURRENT_STYLES} onSelect={() => {
                      if (!multiple) {
                        onChange([option.reference]);
                        setOpen(false);
                      } else if (checked) {
                        if (references.length > 1) onChange(references.filter((reference) => writeStyleReferenceKey(reference) !== option.key));
                      } else if (references.length < MAX_CONCURRENT_STYLES) {
                        onChange([...references, option.reference]);
                      }
                    }}>
                      <span className="writer-style-initial" data-kind={category} aria-hidden="true">{option.label.slice(0, 1)}</span>
                      <span className="writer-style-option-copy"><strong>{option.label}</strong><small>{option.meta}</small></span>
                      <span className="writer-style-check" data-checked={checked} aria-label={checked ? "已选" : undefined}>{checked ? <Check size={15} /> : null}</span>
                    </Command.Item>
                  );
                })}
              </Command.List>
            </Command>
            {multiple ? <div className="writer-style-popover-footer"><span role="status">已选 {references.length} / {MAX_CONCURRENT_STYLES}</span><Popover.Close asChild><button className="btn small" type="button">完成</button></Popover.Close></div> : null}
          </Popover.Content>
        </Popover.Portal>
      </Popover.Root>
      {selected.length > 1 ? <div className="writer-style-chips" aria-label="已选风格卡">
        {selected.map((option) => <span className="writer-style-chip" key={option.key}>
          {option.reference.targetType === "project" ? <Folder size={12} aria-hidden="true" /> : <UserRound size={12} aria-hidden="true" />}
          <span>{option.label}</span>
          <button type="button" disabled={disabled} title={`移除${option.label}`} aria-label={`移除${option.label}风格`} onClick={() => onChange(references.filter((reference) => writeStyleReferenceKey(reference) !== option.key))}><X size={12} aria-hidden="true" /></button>
        </span>)}
      </div> : null}
    </div>
  );
}
